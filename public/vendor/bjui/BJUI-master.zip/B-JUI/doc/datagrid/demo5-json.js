[
    {"name":"孙悟空","firstname":"Sun","lastname":"Wukong"},
    {"name":"罗宾汉","firstname":"Luo","lastname":"Binhan"},
    {"name":"美国队长","firstname":"Meiguo","lastname":"Duizhang"}
]