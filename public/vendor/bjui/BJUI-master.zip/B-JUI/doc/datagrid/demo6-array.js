[
    ["孙悟空", "Sun", "Wukong"],
    ["罗宾汉", "Luo", "Binhan"],
    ["美国队长", "Meiguo", "Duizhang"]
]