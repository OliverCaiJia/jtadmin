[
    {"sex":true,"name":"孙悟空","firstname":"Sun","lastname":"Wukong","operation":"01","age":2000,"passportno":"0000011A","nation":"CN","issuestate":"ok","issuedate":"1900-05-01","isdisable":false,"createtime":"2014-10-24 15:50"},
    {"sex":true,"name":"罗宾汉","firstname":"Luo","lastname":"Binhan","operation":"02","age":800,"passportno":"0000011B","nation":"UK","issuestate":"ok","issuedate":"1950-05-01","isdisable":true,"createtime":"2014-10-24 15:50"},
    {"sex":true,"name":"美国队长","firstname":"Meiguo","lastname":"Duizhang","operation":"03","age":150,"passportno":"0000011C","nation":"US","issuestate":"invalid","issuedate":"1980-05-01","isdisable":false,"createtime":"2014-10-24 15:50"}
]