[
    {"ok":"正常"},
    {"invalid":"失效"},
    {"disable":"禁用"}
]